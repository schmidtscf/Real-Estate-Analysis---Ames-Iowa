import flask
app = flask.Flask(__name__)

#-------- MODEL GOES HERE -----------#
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression


PREDICTOR = pd.read_pickle("REmodel")
#-------- ROUTES GO HERE -----------#
@app.route('/predict', methods=["GET"])
def predict():
    try:
        pclass = flask.request.args['pclass']
    except:
        pclass=2
    sex = flask.request.args['sex']
    age = flask.request.args['age']
    fare = flask.request.args['fare']
    sibsp = flask.request.args['sibsp']

    item = [pclass, sex, age, fare, sibsp]
    score = PREDICTOR.predict_proba(item)
    if score[0,1]> .5:
        data_uri = open('smileyface.png', 'rb').read().encode('base64').replace('\n', '')
        img_tag = '<img src="data:image/png;base64,{0}">'.format(data_uri)
        print(img_tag)
        myImage = Image("smileyface.png");
        return myImage.show();
    else:
        data_uri = open('Death.png', 'rb').read().encode('base64').replace('\n', '')
        img_tag = '<img src="data:image/png;base64,{0}">'.format(data_uri)
        print(img_tag)
        myImage = Image("Death.png");
        return myImage.show();
    results = {'survival chances': score[0,1], 'death chances': score[0,0]}
    return results, myImage.show()

@app.route('/page')
def page():
   with open("page.html", 'r') as viz_file:
       return viz_file.read()

@app.route('/result', methods=['POST', 'GET'])
def result():
    '''Gets prediction using the HTML form'''
    if flask.request.method == 'POST':

       inputs = flask.request.form

       OverallQual = inputs['OverallQual'][0]
       OverallCond = inputs['OverallCond'][0]
       YearBuilt = inputs['YearBuilt'][0]
       YearRemodAdd = inputs['YearRemodAdd'][0]
       GrLivArea = inputs['GrLivArea'][0]
       BedroomAbvGr = inputs['BedroomAbvGr'][0]
       KitchenAbvGr = inputs['KitchenAbvGr'][0]
       MoSold= inputs['MoSold'][0]
       YrSold = inputs['YrSold'][0]
       Blueste, BrDale, BrkSide, ClearCr, CollgCr, Crawfor, \
       Edwards, Gilbert, IDOTRR, MeadowV, Mitchel, NAmes,NPkVill, NWAmes, NoRidge, NridgHt, OldTown, \
       SWISU,Sawyer, SawyerW, Somerst, StoneBr, Timber, Veenker = 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0

       fmCon2 = flask.request.args['2fmCon']
       Duplex = flask.request.args['Duplex']
       Twnhs = flask.request.args['Twnhs']
       TwnhsE = flask.request.args['TwnhsE']
       Unf15 = flask.request.args['1.5Unf']
       Story1 = flask.request.args['1Story']
       Fin25 = flask.request.args['2.5Fin']
       Unf25 = flask.request.args['2.5Unf']
       SFoyer = flask.request.args['SFoyer']
       SLvl = flask.request.args['SLvl']
       Gable = flask.request.args['Gable']
       Gambrel = flask.request.args['Gambrel']
       Hip = flask.request.args['Hip']
       Mansard = flask.request.args['Mansard']
       Shed = flask.request.args['Shed']
       CompShg = flask.request.args['CompShg']
       Membran = flask.request.args['Membran']
       Metal = flask.request.args['Metal']
       Roll = flask.request.args['Roll']
       TarGrv = flask.request.args['TarGrv']
       WdShake = flask.request.args['WdShake']
       WdShngl = flask.request.args['WdShngl']
       total_bath = flask.request.args['total_bath']
       LogLotArea = np.log(logflask.request.args['LotArea'])
       Story2 = flask.request.args['2Story']

       hoodvars = [Blueste, BrDale, BrkSide, ClearCr, CollgCr, Crawfor, \
       Edwards, Gilbert, IDOTRR, MeadowV, Mitchel, NAmes,NPkVill, NWAmes, NoRidge, NridgHt, OldTown, \
       SWISU,Sawyer, SawyerW, Somerst, StoneBr, Timber, Veenker]
       hoods = [u'Blueste', u'BrDale', u'BrkSide', u'ClearCr', u'CollgCr', u'Crawfor',
       u'Edwards', u'Gilbert', u'IDOTRR', u'MeadowV', u'Mitchel', u'NAmes',
       u'NPkVill', u'NWAmes', u'NoRidge', u'NridgHt', u'OldTown', u'SWISU',
       u'Sawyer', u'SawyerW', u'Somerst', u'StoneBr', u'Timber', u'Veenker']

       neigh = flask.request.args['neigh']
       try:
           hoodvars[hoods.index(neigh)] = 1
       except:
           pass

       item = np.array([OverallQual, OverallCond, YearBuilt, YearRemodAdd, GrLivArea, BedroomAbvGr, KitchenAbvGr,MoSold,YrSold,\
       Blueste, BrDale, BrkSide, ClearCr, CollgCr, Crawfor, Edwards, Gilbert, IDOTRR, MeadowV, Mitchel, NAmes, NPkVill, NAmes,\
       NoRidge, NridgHt, OldTown, SWISU, Sawyer, SawyerW, Somerst, StoneBr, Timber, Veenker,\
       fmCon2, Duplex, Twnhs, TwnhsE, Unf15, Story1, Fin25, Story2, Unf25, SFoyer, SLvl, Gable, Gambrel, Hip, Mansard, Shed, CompShg, Membran, Metal, Roll,\
       TarGrv, WdShake, WdShngl, total_bath, LogLotArea])
       price = PREDICTOR.predict(item)
       results = {"Estimated Price":price}
       return flask.jsonify(results)

if __name__ == '__main__':
    '''Connects to the server'''

    HOST = '127.0.0.1'
    PORT = '4000'

    app.run(HOST, PORT)
